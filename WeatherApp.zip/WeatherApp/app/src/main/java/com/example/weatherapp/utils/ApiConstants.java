package com.example.weatherapp.utils;

public class ApiConstants {

    public static final String API_KEY = "16ba2c20e0063cc1ed0de7ba84a1f62c";
    public static final String UNIT = "metric";
    public static final String WEATHER_MAP_BASE_URL = "https://api.openweathermap.org/data/2.5/";
}
